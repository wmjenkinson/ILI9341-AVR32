/*
 * application_mode_routine.h
 *
 * Created: 16/06/2017 13:24:19
 *  Author: William
 */ 
/*
 * Copyright (c) 2017 Queens University Belfast.
 * All rights reserved. 
 * 
 * Redistribution and use in source and binary forms, with or without modification, 
 * are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice,
 *    this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 * 3. The name of the author may not be used to endorse or promote products
 *    derived from this software without specific prior written permission. 
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR IMPLIED 
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF 
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT 
 * SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT 
 * OF SUBSTITUTE GOODS OR serviceS; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS 
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN 
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING 
 * IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY 
 * OF SUCH DAMAGE.
 *
 * This file is part of the Darkness Real-time Kernel.
 * 
 * Author: William Jenkinson <wm.jenkinson@hotmail.com */
/*
 * mandlebrot.h
 *
 * Created: 07/04/2017 23:12:02
 *  Author: wmjen
 */ 


#ifndef MANDLEBROT_H_
#define MANDLEBROT_H_

#include <math.h>
#include <stdlib.h>
#include <stdio.h>

/* "The Mandelbrot Set is the most complex object in mathematics, its admirers like to say. An eternity would not be enough time to see it all, its disks studded with prickly thorns, its spirals and filaments curling outward and around, bearing bulbous molecules that hang, infinitely variegated, like grapes on God's personal vine."
[James Gleick, "Chaos: Making a New Science"] */

#include "Darkness_Kernel/Drivers/ILI9341_Driver/ili9341gfx.h"

extern unsigned char * display_ram;
extern unsigned char * return_dsp_ram_addr;

typedef struct _RGB24 RGB24;
	struct _RGB24 {
		unsigned char B;
		unsigned char G;
		unsigned char R;
	};

struct RgbColor
{
	unsigned char r;
	unsigned char g;
	unsigned char b;
} color;

struct HsvColor
{
	unsigned char h;
	unsigned char s;
	unsigned char v;
} hsv;


static struct RgbColor HsvToRgb(struct HsvColor hsv)
{
    struct RgbColor rgb;
    unsigned char region, p, q, t;
    unsigned int h, s, v, remainder;

    if (hsv.s == 0)
    {
        rgb.r = hsv.v;
        rgb.g = hsv.v;
        rgb.b = hsv.v;
        return rgb;
    }

    // converting to 16 bit to prevent overflow
    h = hsv.h;
    s = hsv.s;
    v = hsv.v;

    region = h / 43;
    remainder = (h - (region * 43)) * 6; 

    p = (v * (255 - s)) >> 8;
    q = (v * (255 - ((s * remainder) >> 8))) >> 8;
    t = (v * (255 - ((s * (255 - remainder)) >> 8))) >> 8;

    switch (region)
    {
        case 0:
            rgb.r = v;
            rgb.g = t;
            rgb.b = p;
            break;
        case 1:
            rgb.r = q;
            rgb.g = v;
            rgb.b = p;
            break;
        case 2:
            rgb.r = p;
            rgb.g = v;
            rgb.b = t;
            break;
        case 3:
            rgb.r = p;
            rgb.g = q;
            rgb.b = v;
            break;
        case 4:
            rgb.r = t;
            rgb.g = p;
            rgb.b = v;
            break;
        default:
            rgb.r = v;
            rgb.g = p;
            rgb.b = q;
            break;
    }

    return rgb;
}



void mandlebrot(void);
void mandlebrot(void)
{
	
	display_ram = return_dsp_ram_addr;
	
	int w = 320, h = 240, x, y;
	//each iteration, it calculates: newz = oldz*oldz + p, where p is the current pixel, and oldz stars at the origin
	double pr, pi;                   //real and imaginary part of the pixel p
	double newRe, newIm, oldRe, oldIm;   //real and imaginary parts of new and old z
	double zoom = 1, moveX = -0.5, moveY = 0; //you can change these to zoom and change position
	int maxIterations = 100;//after how much iterations the function should stop



	//loop through every pixel
	for(x = 0; x < w; x++)
	{

		for(y = 0; y < h; y++)
		{
			//calculate the initial real and imaginary part of z, based on the pixel location and zoom and position values
			pr = 1.5 * (x - w / 2) / (0.5 * zoom * w) + moveX;
			pi = (y - h / 2) / (0.5 * zoom * h) + moveY;
			newRe = newIm = oldRe = oldIm = 0; //these should start at 0,0
			//"i" will represent the number of iterations
			int i;
			//start the iteration process
			for(i = 0; i < maxIterations; i++)
			{
				//remember value of previous iteration
				oldRe = newRe;
				oldIm = newIm;
				//the actual iteration, the real and imaginary part are calculated
				newRe = oldRe * oldRe - oldIm * oldIm + pr;
				newIm = 2 * oldRe * oldIm + pi;
				//if the point is outside the circle with radius 2: stop
				if((newRe * newRe + newIm * newIm) > 4) break;
			}
			  
			  extern unsigned char * display_ram;
			  
			  if(i == maxIterations){
					drawPixel(x, y, 0); // black
					
					* display_ram = 0; display_ram++;
					* display_ram = 0; display_ram++;
			  }
			  else
			  {
				 hsv.h = i % 256;
				 hsv.s = 255;
				 hsv.v = 255 * (i < maxIterations);
				 
				 color = HsvToRgb(hsv);
				 
				 
				RGB24 s; // source
				unsigned short d; // destination
				unsigned short r;
				unsigned short g;
				unsigned short b;
		
				s.R = color.r;
				s.G = color.g;
				s.B = color.b;
				//color(i % 256, 255, 255 * (i < maxIterations));
		
				// Code to convert from 24-bit to 16 bit
				r = (unsigned short)((double)(s.R * 31) / 255.0);
				g = (unsigned short)((double)(s.G * 63) / 255.0);
				b = (unsigned short)((double)(s.B * 31) / 255.0);
				d = (r << 11) | (g << 5) | (b << 0);		

				drawPixel(x, y, d);	
				
				unsigned char hi_byte = d >> 8;
				unsigned char low_byte = d;
				
				* display_ram = hi_byte;	display_ram++;
				* display_ram = low_byte;	display_ram++; 
			}
		}
		extern char anykey(void); if(anykey() == SEM_ACK)
									break;
	}
	
	while(true){
		extern char anykey(void); if(anykey() == SEM_ACK)
									break;
	}
	extern void refresh_dsp(void); refresh_dsp();
}



void julia_set(void);
void julia_set(void)
{
	
	display_ram = return_dsp_ram_addr;
	
	int w = 320, h = 240;
	
	//each iteration, it calculates: new = old*old + c, where c is a constant and old starts at current pixel
	double cRe, cIm;           //real and imaginary part of the constant c, determinate shape of the Julia Set
	double newRe, newIm, oldRe, oldIm;   //real and imaginary parts of new and old
	double zoom = 1, moveX = 0, moveY = 0; //you can change these to zoom and change position
	
	int maxIterations = 100; //after how much iterations the function should stop

	//pick some values for the constant c, this determines the shape of the Julia Set
	cRe = -0.7;
	cIm = 0.27015;

	//loop through every pixel
	for(int y = 0; y < h; y++){
	for(int x = 0; x < w; x++)
	{
		//calculate the initial real and imaginary part of z, based on the pixel location and zoom and position values
		newRe = 1.5 * (x - w / 2) / (0.5 * zoom * w) + moveX;
		newIm = (y - h / 2) / (0.5 * zoom * h) + moveY;
		//i will represent the number of iterations
		int i;
		//start the iteration process
		for(i = 0; i < maxIterations; i++)
		{
			//remember value of previous iteration
			oldRe = newRe;
			oldIm = newIm;
			//the actual iteration, the real and imaginary part are calculated
			newRe = oldRe * oldRe - oldIm * oldIm + cRe;
			newIm = 2 * oldRe * oldIm + cIm;
			//if the point is outside the circle with radius 2: stop
			if((newRe * newRe + newIm * newIm) > 4) break;
		}
			 hsv.h = i % 256;
			 hsv.s = 255;
			 hsv.v = 255 * (i < maxIterations);
			 
			 color = HsvToRgb(hsv);
			  
			  RGB24 s; // source
			  unsigned short d; // destination
			  unsigned short r;
			  unsigned short g;
			  unsigned short b;

			  s.R = color.r;
			  s.G = color.g;
			  s.B = color.b;
			  
			  // Code to convert from 24-bit to 16 bit
			  r = (unsigned short)((double)(s.R * 31) / 255.0);
			  g = (unsigned short)((double)(s.G * 63) / 255.0);
			  b = (unsigned short)((double)(s.B * 31) / 255.0);
			  d = (r << 11) | (g << 5) | (b << 0);

			  drawPixel(x, y, d);	
			  
			  char hi_byte = d >> 8;
			  char low_byte = d;
			  
			  * display_ram = hi_byte;	display_ram++;
			  * display_ram = low_byte;	display_ram++;
			  
			  }
		extern char anykey(void); if(anykey() == SEM_ACK)
										break;
	}
	
	while(true){
		extern char anykey(void); if(anykey() == SEM_ACK)
									break;
	}
	extern void refresh_dsp(void); refresh_dsp();
}


const double PI = 3.1415926535897931;



// left, top, width , height, screen width, screen height, max iterations, data[sw*sh]
void tetration(void);
void tetration(void)
{
	display_ram = return_dsp_ram_addr;
	
    for (int ky = 0; ky < 240; ky++) {
        for (int kx = 0; kx < 340; kx++) {
				
			//	drawing area (xa < xb & ya < yb)
			//  x = xa + (xb - xa) * kx / (imgx - 1)
			//  y = ya + (yb - ya) * ky / (imgy - 1)
			
            float x = -1.5 + (-0.75 - -1.5) * kx / (320 - 1);
            float y = 0.0 + (0.75 + 0.0) * ky / (240 - 1);
            int i = 0;
            for (; i < 100 - 1; i++) {
                float e = exp(-0.5 * PI * y);
                if (e != e) break;
                float p = PI * x * 0.5;
                x = e * cos(p);
                y = e * sin(p);
                if (x * x + y * y > 1e12) break;
            }
             RGB24 s; // source
             unsigned short d; // destination
             unsigned short r;
             unsigned short g;
             unsigned short b;

             s.R = i % 4 * 64;
             s.G = i % 8 * 32;
             s.B = i % 16 * 16;
             
             // Code to convert from 24-bit to 16 bit
             r = (unsigned short)((double)(s.R * 31) / 255.0);
             g = (unsigned short)((double)(s.G * 63) / 255.0);
             b = (unsigned short)((double)(s.B * 31) / 255.0);
             d = (r << 11) | (g << 5) | (b << 0);

             drawPixel(kx, ky, d);
			 
			  char hi_byte =  d >> 8;
			  char low_byte = d;
			  
			  * display_ram = hi_byte;	display_ram++;
			  * display_ram = low_byte;	display_ram++;
        }
		extern char anykey(void); if(anykey() == SEM_ACK)
										break;
	}
	
	while(true){
		extern char anykey(void); if(anykey() == SEM_ACK)
										break;
	}
	extern void refresh_dsp(void); refresh_dsp();
}


void DoFractal(void);
void DoFractal(void) {
	
	display_ram = return_dsp_ram_addr;
	
	for (int y=0; y<240; y++) {
		for (int x=0; x<360; x++) {
			int iter = 0;
			
			_Complex float z = 0 + 0i;
			_Complex float c = 2.0*(x-360/ 2)/360 + 2.0*(y-240/2)/240i;
			
			while (iter < 100) {
				
				z = z * z + c;
			
				if (abs(z) > 2) break;
				iter++;
			}
			RGB24 s; // source
			unsigned short d; // destination
			unsigned short r;
			unsigned short g;
			unsigned short b;

			s.R = iter % 4 * 64;
			s.G = iter % 8 * 32;
			s.B = iter % 16 * 16;
			
			// Code to convert from 24-bit to 16 bit
			r = (unsigned short)((double)(s.R * 31) / 255.0);
			g = (unsigned short)((double)(s.G * 63) / 255.0);
			b = (unsigned short)((double)(s.B * 31) / 255.0);
			d = (r << 11) | (g << 5) | (b << 0);

			drawPixel(x, y, d);
			
			unsigned char hi_byte = d >> 8;
			unsigned char low_byte = d;
			
			* display_ram = hi_byte;	display_ram++;
			* display_ram = low_byte;	display_ram++;
		}
		extern char anykey(void); if(anykey() == SEM_ACK)
									break;
	}
	while(true){
		extern char anykey(void); if(anykey() == SEM_ACK)
									break;
	}
	extern void refresh_dsp(void); refresh_dsp();
}
#endif /* MANDLEBROT_H_ */