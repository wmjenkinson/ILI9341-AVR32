// https://github.com/PaulStoffregen/ILI9341_t3
// http://forum.pjrc.com/threads/26305-Highly-optimized-ILI9341-(320x240-TFT-color-display)-library

/***************************************************
  This is our library for the Adafruit ILI9341 Breakout and Shield
  ----> http://www.adafruit.com/products/1651

  Check out the links above for our tutorials and wiring diagrams
  These displays use SPI to communicate, 4 or 5 pins are required to
  interface (RST is optional)
  Adafruit invests time and resources providing this open source code,
  please support Adafruit and open-source hardware by purchasing
  products from Adafruit!

  Written by Limor Fried/Ladyada for Adafruit Industries.
  MIT license, all text above must be included in any redistribution

 **************************************************
//Additional graphics routines by Tim Trzepacz, SoftEgg LLC added December 2015
//(And then accidentally deleted and rewritten March 2016. Oops!)
//Gradient support 
//----------------
//		fillRectVGradient	- fills area with vertical gradient
//		fillRectHGradient	- fills area with horizontal gradient
//		fillScreenVGradient - fills screen with vertical gradient
// 	fillScreenHGradient - fills screen with horizontal gradient

//Additional Color Support
//------------------------
//		color565toRGB		- converts 565 format 16 bit color to RGB
//		color565toRGB14		- converts 16 bit 565 format color to 14 bit RGB (2 bits clear for math and sign)
//		RGB14tocolor565		- converts 14 bit RGB back to 16 bit 565 format color

//Low Memory Bitmap Support
//-------------------------
// 		writeRect8BPP - 	write 8 bit per pixel paletted bitmap
// 		writeRect4BPP - 	write 4 bit per pixel paletted bitmap
// 		writeRect2BPP - 	write 2 bit per pixel paletted bitmap
// 		writeRect1BPP - 	write 1 bit per pixel paletted bitmap

//TODO: transparent bitmap writing routines for sprites

//String Pixel Length support 
//---------------------------
//		strPixelLen			- gets pixel length of given ASCII string
*/

#include "Darkness_Kernel/Drivers/ILI9341_Driver/ili9341gfx.h"
#include "Darkness_Kernel/Drivers/ILI9341_Driver/GenricFont/GenericFont.h"
#include "Darkness_Kernel/Drivers/ILI9341_Driver/GenricFont/font_Arial.h"

extern void ili9341_send_command(uint8_t);
extern void ili9341_send_byte(uint8_t);

void setAddr(int x0, int y0, int x1, int y1){

	ili9341_send_command(ILI9341_CASET); // Column addr set

	ili9341_send_byte(x0 >> 8);
	ili9341_send_byte(x0 & 0xFF);
	
	ili9341_send_byte(x1 >> 8);
	ili9341_send_byte(x1 & 0xFF);
	
	ili9341_send_command(ILI9341_PASET); // Row addr set

	ili9341_send_byte(y0 >> 8);
	ili9341_send_byte(y0 & 0xFF);
	
	ili9341_send_byte(y1 >> 8);
	ili9341_send_byte(y1 & 0xFF);
}


void Pixel(int16_t x, int16_t y, uint16_t color){

	if((x >= ILI9341_DEFAULT_WIDTH) || (x < 0) || (y >= ILI9341_DEFAULT_HEIGHT) || (y < 0)) return;

	setAddr(x, y, x, y);
	ili9341_send_command(ILI9341_RAMWR);
	ili9341_send_byte(color >> 8);
	ili9341_send_byte(color & 0xFF);
}

void HLine(int16_t x, int16_t y, int16_t w, uint16_t color){

	if((x >= ILI9341_DEFAULT_WIDTH) || (y >= ILI9341_DEFAULT_HEIGHT) || (y < 0)) return;
	if(x < 0) {	w += x; x = 0; 	}
	if((x+w-1) >= ILI9341_DEFAULT_WIDTH)  w = ILI9341_DEFAULT_WIDTH-x;

	setAddr(x, y, x+w-1, y);

	ili9341_send_command(ILI9341_RAMWR);

	do { ili9341_send_byte(color >> 8);
	ili9341_send_byte(color & 0xFF); } while (--w > 0);

}

void VLine(int16_t x, int16_t y, int16_t h, uint16_t color){

	if((x >= ILI9341_DEFAULT_WIDTH) || (x < 0) || (y >= ILI9341_DEFAULT_HEIGHT)) return;
	if(y < 0) {	h += y; y = 0; 	}
	if((y+h-1) >= ILI9341_DEFAULT_HEIGHT) h = ILI9341_DEFAULT_HEIGHT-y;

	setAddr(x, y, x, y+h-1);

	ili9341_send_command(ILI9341_RAMWR);
	do { ili9341_send_byte(color >> 8);
	ili9341_send_byte(color & 0xFF); } while (--h > 0);
}

//RGB14tocolor565		- converts 14 bit RGB back to 16 bit 565 format color
uint16_t RGB14tocolor565(int16_t r, int16_t g, int16_t b){
	return (((r & 0x3E00) << 2) | ((g & 0x3F00) >>3) | ((b & 0x3E00) >> 9));
}

// Pass 8-bit (each) R,G,B, get back 16-bit packed color
uint16_t color565(uint8_t r, uint8_t g, uint8_t b) {
	return ((r & 0xF8) << 8) | ((g & 0xFC) << 3) | (b >> 3);
}

//color565toRGB		- converts 565 format 16 bit color to RGB
void color565toRGB(uint16_t color, uint8_t *r, uint8_t *g, uint8_t *b){

	*r = (color>>8) & 0x00F8;
	*g = (color>>3) & 0x00FC;
	*b = (color<<3) & 0x00F8;
}

void color565toRGB14(uint16_t color, int16_t *r, int16_t *g, int16_t *b){
	
	*r = (color>>2) & 0x3E00;
	*g = (color<<3) & 0x3F00;
	*b = (color<<9) & 0x3E00;
}

void pushColor(uint16_t color){
	ili9341_send_byte(color >> 8);
	ili9341_send_byte(color & 0xFF);
}



void drawPixel(int16_t x, int16_t y, uint16_t color) {

	if((x < 0) ||(x >= ILI9341_DEFAULT_WIDTH) || (y < 0) || (y >= ILI9341_DEFAULT_HEIGHT)) return;

	setAddr(x, y, x, y);

	ili9341_send_command(ILI9341_RAMWR);
	ili9341_send_byte(color >> 8);
	ili9341_send_byte(color & 0xFF);
}

void drawFastVLine(int16_t x, int16_t y, int16_t h, uint16_t color)
{

	// Rudimentary clipping

	if((x >= ILI9341_DEFAULT_WIDTH) || (x < 0) || (y >= ILI9341_DEFAULT_HEIGHT)) return;

	if(y < 0) {	h += y; y = 0; 	}

	if((y+h-1) >= ILI9341_DEFAULT_HEIGHT) h = ILI9341_DEFAULT_HEIGHT-y;

	setAddr(x, y, x, y+h-1);

	ili9341_send_command(ILI9341_RAMWR);

	while (h-- > 1) {
		ili9341_send_byte(color >> 8);
		ili9341_send_byte(color & 0xFF);
	}
	ili9341_send_byte(color >> 8);
	ili9341_send_byte(color & 0xFF);
}

void drawFastHLine(int16_t x, int16_t y, int16_t w, uint16_t color){

	// Rudimentary clipping

	if((x >= ILI9341_DEFAULT_WIDTH) || (y >= ILI9341_DEFAULT_HEIGHT) || (y < 0)) return;

	if(x < 0) {	w += x; x = 0; 	}

	if((x+w-1) >= ILI9341_DEFAULT_WIDTH)  w = ILI9341_DEFAULT_WIDTH-x;


	setAddr(x, y, x+w-1, y);

	ili9341_send_command(ILI9341_RAMWR);

	while (w-- > 1) {
		ili9341_send_byte(color >> 8);
		ili9341_send_byte(color & 0xFF);
	}
	ili9341_send_byte(color >> 8);
	ili9341_send_byte(color & 0xFF);
}

// fill a rectangle
void fillRect(int16_t x, int16_t y, int16_t w, int16_t h, uint16_t color){
	// rudimentary clipping (drawChar w/big text requires this)
	if((x >= ILI9341_DEFAULT_WIDTH) || (y >= ILI9341_DEFAULT_HEIGHT)) return;

	if(x < 0) {	w += x; x = 0; 	}
	if(y < 0) {	h += y; y = 0; 	}

	if((x + w - 1) >= ILI9341_DEFAULT_WIDTH)  w = ILI9341_DEFAULT_WIDTH  - x;
	if((y + h - 1) >= ILI9341_DEFAULT_HEIGHT) h = ILI9341_DEFAULT_HEIGHT - y;



	// TODO: this can result in a very long transaction time
	// should break this into multiple transactions, even though
	// it'll cost more overhead, so we don't stall other SPI libs

	setAddr(x, y, x+w-1, y+h-1);

	ili9341_send_command(ILI9341_RAMWR);

	for(y=h; y>0; y--) {
		for(x=w; x>1; x--) {
			ili9341_send_byte(color >> 8);
			ili9341_send_byte(color & 0xFF);
		}
		ili9341_send_byte(color >> 8);
		ili9341_send_byte(color & 0xFF);
	}
}

// fillRectVGradient	- fills area with vertical gradient
void fillRectVGradient(int16_t x, int16_t y, int16_t w, int16_t h, uint16_t color1, uint16_t color2){

	// rudimentary clipping (drawChar w/big text requires this)
	if((x >= ILI9341_DEFAULT_WIDTH) || (y >= ILI9341_DEFAULT_HEIGHT)) return;

	if((x + w - 1) >= ILI9341_DEFAULT_WIDTH)  w = ILI9341_DEFAULT_WIDTH  - x;
	if((y + h - 1) >= ILI9341_DEFAULT_HEIGHT) h = ILI9341_DEFAULT_HEIGHT - y;


	int16_t r1, g1, b1, r2, g2, b2, dr, dg, db, r, g, b;

	color565toRGB14(color1, &r1, &g1, &b1);
	color565toRGB14(color2, &r2, &g2, &b2);

	dr=(r2-r1)/h; dg=(g2-g1)/h; db=(b2-b1)/h;
	r=r1; g=g1; b=b1;



	// TODO: this can result in a very long transaction time
	// should break this into multiple transactions, even though
	// it'll cost more overhead, so we don't stall other SPI libs
	setAddr(x, y, x+w-1, y+h-1);

	ili9341_send_command(ILI9341_RAMWR);

	for(y=h; y>0; y--) {

		uint16_t color = RGB14tocolor565(r, g, b);

		for(x=w; x>1; x--) {
			ili9341_send_byte(color >> 8);
			ili9341_send_byte(color & 0xFF);
		}
		ili9341_send_byte(color >> 8);
		ili9341_send_byte(color & 0xFF);
		r+=dr;g+=dg; b+=db;
	}
}

// fillRectHGradient	- fills area with horizontal gradient
void fillRectHGradient(int16_t x, int16_t y, int16_t w, int16_t h, uint16_t color1, uint16_t color2){

	// rudimentary clipping (drawChar w/big text requires this)

	if((x >= ILI9341_DEFAULT_WIDTH) || (y >= ILI9341_DEFAULT_HEIGHT)) return;
	if((x + w - 1) >= ILI9341_DEFAULT_WIDTH)  w = ILI9341_DEFAULT_WIDTH  - x;
	if((y + h - 1) >= ILI9341_DEFAULT_HEIGHT) h = ILI9341_DEFAULT_HEIGHT - y;

	int16_t r1, g1, b1, r2, g2, b2, dr, dg, db, r, g, b;

	color565toRGB14(color1, &r1, &g1, &b1);
	color565toRGB14(color2, &r2, &g2, &b2);

	dr=(r2-r1)/h; dg=(g2-g1)/h; db=(b2-b1)/h;

	r=r1;g=g1;b=b1;

	// TODO: this can result in a very long transaction time
	// should break this into multiple transactions, even though
	// it'll cost more overhead, so we don't stall other SPI libs
	setAddr(x, y, x+w-1, y+h-1);

	ili9341_send_command(ILI9341_RAMWR);

	for(y=h; y>0; y--) {

		uint16_t color;

		for(x=w; x>1; x--) {

			color = RGB14tocolor565(r,g,b);

			ili9341_send_byte(color >> 8);
			ili9341_send_byte(color & 0xFF);
			r+=dr;g+=dg; b+=db;
		}
		color = RGB14tocolor565(r,g,b);

		ili9341_send_byte(color >> 8);
		ili9341_send_byte(color & 0xFF);
		r=r1;g=g1;b=b1;
	}
}


#define MADCTL_MY  0x80
#define MADCTL_MX  0x40
#define MADCTL_MV  0x20
#define MADCTL_ML  0x10
#define MADCTL_RGB 0x00
#define MADCTL_BGR 0x08
#define MADCTL_MH  0x04

void setRotation(uint8_t m){

	int rotation = m % 4; // can't be higher than 3

	ili9341_send_command(ILI9341_MADCTL);

	switch (rotation) {

		case 0:
		ili9341_send_byte(MADCTL_MX | MADCTL_BGR);
		break;

		case 1:
		ili9341_send_byte(MADCTL_MV | MADCTL_BGR);
		break;

		case 2:
		ili9341_send_byte(MADCTL_MY | MADCTL_BGR);
		break;

		case 3:
		ili9341_send_byte(MADCTL_MX | MADCTL_MY | MADCTL_MV | MADCTL_BGR);
		break;
	}
}


void setScroll(uint16_t offset){
	ili9341_send_command(ILI9341_VSCRSADD);
	ili9341_send_byte(offset >> 8);
	ili9341_send_byte(offset & 0xFF);
}

void invertDisplay(Bool i){
	ili9341_send_command(i ? ILI9341_INVON : ILI9341_INVOFF);
}

void fillScreen(uint16_t color){
	fillRect(0, 0, ILI9341_DEFAULT_WIDTH, ILI9341_DEFAULT_HEIGHT, color);
}

// fillScreenVGradient - fills screen with vertical gradient
void fillScreenVGradient(uint16_t color1, uint16_t color2){
	fillRectVGradient(0, 0, ILI9341_DEFAULT_WIDTH, ILI9341_DEFAULT_HEIGHT, color1, color2);
}

// fillScreenHGradient - fills screen with horizontal gradient
void fillScreenHGradient(uint16_t color1, uint16_t color2){
	fillRectHGradient(0, 0, ILI9341_DEFAULT_WIDTH, ILI9341_DEFAULT_HEIGHT, color1, color2);
}

// Draw a circle outline
void drawCircle(int16_t x0, int16_t y0, int16_t r, uint16_t color) {

	int16_t f = 1 - r;
	int16_t ddF_x = 1;
	int16_t ddF_y = -2 * r;
	int16_t x = 0;
	int16_t y = r;

	drawPixel(x0  , y0+r, color);
	drawPixel(x0  , y0-r, color);
	drawPixel(x0+r, y0  , color);
	drawPixel(x0-r, y0  , color);

	while (x<y) {

		if (f >= 0) {
			y--;
			ddF_y += 2;
			f += ddF_y;
		}
		x++;

		ddF_x += 2;

		f += ddF_x;

		drawPixel(x0 + x, y0 + y, color);
		drawPixel(x0 - x, y0 + y, color);
		drawPixel(x0 + x, y0 - y, color);
		drawPixel(x0 - x, y0 - y, color);
		drawPixel(x0 + y, y0 + x, color);
		drawPixel(x0 - y, y0 + x, color);
		drawPixel(x0 + y, y0 - x, color);
		drawPixel(x0 - y, y0 - x, color);
	}
}


void drawCircleHelper( int16_t x0, int16_t y0, int16_t r, uint8_t cornername, uint16_t color) {

	int16_t f     = 1 - r;
	int16_t ddF_x = 1;
	int16_t ddF_y = -2 * r;
	int16_t x     = 0;
	int16_t y     = r;

	while (x<y) {

		if (f >= 0) {

			y--;

			ddF_y += 2;
			f += ddF_y;
		}

		x++;

		ddF_x += 2;
		f += ddF_x;

		if (cornername & 0x4) {
			drawPixel(x0 + x, y0 + y, color);
			drawPixel(x0 + y, y0 + x, color);
		}

		if (cornername & 0x2) {
			drawPixel(x0 + x, y0 - y, color);
			drawPixel(x0 + y, y0 - x, color);
		}

		if (cornername & 0x8) {
			drawPixel(x0 - y, y0 + x, color);
			drawPixel(x0 - x, y0 + y, color);
		}

		if (cornername & 0x1) {
			drawPixel(x0 - y, y0 - x, color);
			drawPixel(x0 - x, y0 - y, color);
		}
	}
}

// Used to do circles and roundrects
void fillCircleHelper(int16_t x0, int16_t y0, int16_t r,uint8_t cornername, int16_t delta, uint16_t color) {

	int16_t f     = 1 - r;
	int16_t ddF_x = 1;
	int16_t ddF_y = -2 * r;
	int16_t x     = 0;
	int16_t y     = r;

	while (x<y) {

		if (f >= 0) {

			y--;
			ddF_y += 2;
			f     += ddF_y;
		}

		x++;
		ddF_x += 2;
		f     += ddF_x;

		if (cornername & 0x1) {
			drawFastVLine(x0+x, y0-y, 2*y+1+delta, color);
			drawFastVLine(x0+y, y0-x, 2*x+1+delta, color);
		}

		if (cornername & 0x2) {
			drawFastVLine(x0-x, y0-y, 2*y+1+delta, color);
			drawFastVLine(x0-y, y0-x, 2*x+1+delta, color);
		}
	}
}

void fillCircle(int16_t x0, int16_t y0, int16_t r,uint16_t color) {
	drawFastVLine(x0, y0-r, 2*r+1, color);
	fillCircleHelper(x0, y0, r, 3, 0, color);
}

// Bresenham's algorithm - thx wikpedia
void drawLine(int16_t x0, int16_t y0, int16_t x1, int16_t y1, uint16_t color){

	if (y0 == y1) {
		if (x1 > x0) {
			drawFastHLine(x0, y0, x1 - x0 + 1, color);
		}
		else if (x1 < x0) {
			drawFastHLine(x1, y0, x0 - x1 + 1, color);
		}
		else {
			drawPixel(x0, y0, color);
		}
		return;

	}
	else if (x0 == x1) {
		if (y1 > y0) {
			drawFastVLine(x0, y0, y1 - y0 + 1, color);
		}
		else {
			drawFastVLine(x0, y1, y0 - y1 + 1, color);
		}
		return;
	}

	bool steep = abs(y1 - y0) > abs(x1 - x0);

	if (steep) {

		swap(x0, y0);
		swap(x1, y1);
	}

	if (x0 > x1) {

		swap(x0, x1);
		swap(y0, y1);
	}



	int16_t dx, dy;

	dx = x1 - x0;
	dy = abs(y1 - y0);

	int16_t err = dx / 2;
	int16_t ystep;

	if (y0 < y1) {
		ystep = 1;
	}
	else {
		ystep = -1;
	}

	int16_t xbegin = x0;

	if (steep) {
		for (; x0<=x1; x0++) {
			
			err -= dy;
			if (err < 0) {
				int16_t len = x0 - xbegin;
				if (len) {
					VLine(y0, xbegin, len + 1, color);
				}
				else {
					Pixel(y0, x0, color);
				}
				xbegin = x0 + 1;
				y0 += ystep;
				err += dx;
			}
		}

		if (x0 > xbegin + 1) {
			VLine(y0, xbegin, x0 - xbegin, color);
		}
	}
	else {
		for (; x0<=x1; x0++) {

			err -= dy;
			if (err < 0) {

				int16_t len = x0 - xbegin;
				if (len) {
					HLine(xbegin, y0, len + 1, color);
				}
				else {
					Pixel(x0, y0, color);
				}

				xbegin = x0 + 1;
				y0 += ystep;
				err += dx;
			}
		}
		if (x0 > xbegin + 1) {
			HLine(xbegin, y0, x0 - xbegin, color);
		}
	}
	ili9341_send_command(ILI9341_NOP);
}

// Draw a rectangle
void drawRect(int16_t x, int16_t y, int16_t w, int16_t h, uint16_t color){
	HLine(x, y, w, color);
	HLine(x, y+h-1, w, color);
	VLine(x, y, h, color);
	VLine(x+w-1, y, h, color);
	ili9341_send_command(ILI9341_NOP);
}

// Draw a rounded rectangle
void drawRoundRect(int16_t x, int16_t y, int16_t w, int16_t h, int16_t r, uint16_t color) {

	// smarter version
	drawFastHLine(x+r  , y    , w-2*r, color); // Top
	drawFastHLine(x+r  , y+h-1, w-2*r, color); // Bottom
	drawFastVLine(x    , y+r  , h-2*r, color); // Left
	drawFastVLine(x+w-1, y+r  , h-2*r, color); // Right

	// draw four corners
	drawCircleHelper(x+r    , y+r    , r, 1, color);
	drawCircleHelper(x+w-r-1, y+r    , r, 2, color);
	drawCircleHelper(x+w-r-1, y+h-r-1, r, 4, color);
	drawCircleHelper(x+r    , y+h-r-1, r, 8, color);
}

// Fill a rounded rectangle
void fillRoundRect(int16_t x, int16_t y, int16_t w, int16_t h, int16_t r, uint16_t color) {
	
	// smarter version
	fillRect(x+r, y, w-2*r, h, color);

	// draw four corners
	fillCircleHelper(x+w-r-1, y+r, r, 1, h-2*r-1, color);
	fillCircleHelper(x+r    , y+r, r, 2, h-2*r-1, color);
}

// Draw a triangle
void drawTriangle(int16_t x0, int16_t y0, int16_t x1, int16_t y1, int16_t x2, int16_t y2, uint16_t color) {
	drawLine(x0, y0, x1, y1, color);
	drawLine(x1, y1, x2, y2, color);
	drawLine(x2, y2, x0, y0, color);
}

// Fill a triangle
void fillTriangle ( int16_t x0, int16_t y0, int16_t x1, int16_t y1, int16_t x2, int16_t y2, uint16_t color) {

	int16_t a, b, y, last;

	// Sort coordinates by Y order (y2 >= y1 >= y0)
	if (y0 > y1) {
		swap(y0, y1); swap(x0, x1);
	}

	if (y1 > y2) {
		swap(y2, y1); swap(x2, x1);
	}

	if (y0 > y1) {
		swap(y0, y1); swap(x0, x1);
	}

	if(y0 == y2) { // Handle awkward all-on-same-line case as its own thing

		a = b = x0;

		if(x1 < a)      a = x1;
		else if(x1 > b) b = x1;
		if(x2 < a)      a = x2;
		else if(x2 > b) b = x2;

		drawFastHLine(a, y0, b-a+1, color);
		return;
	}

	int16_t
	dx01 = x1 - x0,
	dy01 = y1 - y0,
	dx02 = x2 - x0,
	dy02 = y2 - y0,
	dx12 = x2 - x1,
	dy12 = y2 - y1,
	sa   = 0,
	sb   = 0;

	// For upper part of triangle, find scanline crossings for segments
	// 0-1 and 0-2.  If y1=y2 (flat-bottomed triangle), the scanline y1
	// is included here (and second loop will be skipped, avoiding a /0
	// error there), otherwise scanline y1 is skipped here and handled
	// in the second loop...which also avoids a /0 error here if y0=y1
	// (flat-topped triangle).

	if(y1 == y2) last = y1;   // Include y1 scanline
	else         last = y1-1; // Skip it

	for(y=y0; y<=last; y++) {

		a   = x0 + sa / dy01;
		b   = x0 + sb / dy02;

		sa += dx01;
		sb += dx02;

		if(a > b) swap(a,b);
		drawFastHLine(a, y, b-a+1, color);
	}

	sa = dx12 * (y - y1);
	sb = dx02 * (y - y0);

	for(; y<=y2; y++) {

		a   = x1 + sa / dy12;
		b   = x0 + sb / dy02;
		sa += dx12;
		sb += dx02;

		if(a > b) swap(a,b);
		drawFastHLine(a, y, b-a+1, color);
	}
}

// Draw a character
void drawChar(int16_t x, int16_t y, unsigned char c, uint16_t fgcolor, uint16_t bgcolor, uint8_t size){

	if((x >= ILI9341_DEFAULT_WIDTH)            || // Clip right
	(y >= ILI9341_DEFAULT_HEIGHT)           || // Clip bottom
	((x + 6 * size - 1) < 0) || // Clip left  TODO: is this correct?
	((y + 8 * size - 1) < 0))   // Clip top   TODO: is this correct?

	return;

	if (fgcolor == bgcolor) {
		// This transparent approach is only about 20% faster
		if (size == 1) {
			
			uint8_t mask = 0x01;
			int16_t xoff, yoff;

			for (yoff=0; yoff < 8; yoff++) {

				uint8_t line = 0;
				for (xoff=0; xoff < 5; xoff++) {

					if (glcdfont[c * 5 + xoff] & mask) line |= 1;
					line <<= 1;
				}

				line >>= 1;
				xoff = 0;

				while (line) {

					if (line == 0x1F) {
						drawFastHLine(x + xoff, y + yoff, 5, fgcolor);
						break;
					}
					else if (line == 0x1E) {
						drawFastHLine(x + xoff, y + yoff, 4, fgcolor);
						break;
					}
					else if ((line & 0x1C) == 0x1C) {
						drawFastHLine(x + xoff, y + yoff, 3, fgcolor);
						line <<= 4;
						xoff += 4;

					}
					else if ((line & 0x18) == 0x18) {
						drawFastHLine(x + xoff, y + yoff, 2, fgcolor);
						line <<= 3;
						xoff += 3;
					}
					else if ((line & 0x10) == 0x10) {
						drawPixel(x + xoff, y + yoff, fgcolor);
						line <<= 2;
						xoff += 2;
						} else {
						line <<= 1;
						xoff += 1;
					}
				}
				mask = mask << 1;
			}
		}
		else {

			uint8_t mask = 0x01;
			int16_t xoff, yoff;
			
			for (yoff=0; yoff < 8; yoff++) {

				uint8_t line = 0;

				for (xoff=0; xoff < 5; xoff++) {

					if (glcdfont[c * 5 + xoff] & mask) line |= 1;

					line <<= 1;

				}

				line >>= 1;
				xoff = 0;

				while (line) {

					if (line == 0x1F) {

						fillRect(x + xoff * size, y + yoff * size, 5 * size, size, fgcolor);
						break;

					}
					else if (line == 0x1E) {

						fillRect(x + xoff * size, y + yoff * size, 4 * size, size, fgcolor);
						break;

					}
					else if ((line & 0x1C) == 0x1C) {

						fillRect(x + xoff * size, y + yoff * size, 3 * size, size, fgcolor);
						line <<= 4;
						xoff += 4;

					}
					else if ((line & 0x18) == 0x18) {

						fillRect(x + xoff * size, y + yoff * size, 2 * size, size, fgcolor);
						line <<= 3;
						xoff += 3;

					}
					else if ((line & 0x10) == 0x10) {

						fillRect(x + xoff * size, y + yoff * size,
						size, size, fgcolor);
						line <<= 2;
						xoff += 2;
					}
					else {

						line <<= 1;
						xoff += 1;
					}
				}
				mask = mask << 1;
			}
		}
	}
	else {

		// This solid background approach is about 5 time faster
		setAddr(x, y, x + 6 * size - 1, y + 8 * size - 1);

		ili9341_send_command(ILI9341_RAMWR);

		uint8_t xr, yr;
		uint8_t mask = 0x01;
		uint16_t color;

		for (y=0; y < 8; y++) {

			for (yr=0; yr < size; yr++) {

				for (x=0; x < 5; x++) {

					if (glcdfont[c * 5 + x] & mask) {
						color = fgcolor;
					}
					else {
						color = bgcolor;
					}
					for (xr=0; xr < size; xr++) {
						ili9341_send_byte(color >> 8);
						ili9341_send_byte(color & 0xFF);
					}
				}
				for (xr=0; xr < size; xr++) {
					ili9341_send_byte(bgcolor >> 8);
					ili9341_send_byte(bgcolor & 0xFF);
				}
			}
			mask = mask << 1;
		}
		ili9341_send_command(ILI9341_NOP);
	}
}


uint32_t fetchbit(const uint8_t *p, uint32_t index){
	if (p[index >> 3] & (1 << (7 - (index & 7)))) return 1;
	return 0;
}



uint32_t fetchbits_unsigned(const uint8_t *p, uint32_t index, uint32_t required){
	uint32_t val = 0;

	do {

		uint8_t b = p[index >> 3];
		uint32_t avail = 8 - (index & 7);

		if (avail <= required) {

			val <<= avail;
			val |= b & ((1 << avail) - 1);

			index += avail;
			required -= avail;
			} else {

			b >>= avail - required;
			val <<= required;

			val |= b & ((1 << required) - 1);
			break;
		}
	} while (required);
	return val;
}



uint32_t fetchbits_signed(const uint8_t *p, uint32_t index, uint32_t required)
{
	uint32_t val = fetchbits_unsigned(p, index, required);

	if (val & (1 << (required - 1))) {
		return (int32_t)val - (1 << required);
	}
	return (int32_t)val;
}

int cursor_y = 0, cursor_x = 0;
int textsize = 1;

size_t write(uint8_t c){
	
	if (font) {
		if (c == '\n') {

			cursor_y += font->line_space; // Fix linefeed. Added by T.T., SoftEgg
			cursor_x = 0;

			} else {
				drawFontChar(c, cursor_x, cursor_y, font);
			}
		} else {

		if (c == '\n') {
			cursor_y += 1*8;
			cursor_x  = 0;
			} else if (c == '\r') {

			// skip em
			} else {
			drawChar(cursor_x, cursor_y, c, ILI9341_WHITE, ILI9341_WHITE, textsize);
			cursor_x += textsize*6;
			if (1 && (cursor_x > (ILI9341_DEFAULT_WIDTH - textsize*6))) {
				cursor_y += textsize*8;
				cursor_x = 0;
			}
		}
	}
	return 1;
}


int drawFontChar(char c, int cursor_x, int cursor_y, ILI9341_t3_font_t * font){

	uint32_t bitoffset;
	
	const uint8_t *data;
	
	if (c >= font->index1_first && c <= font->index1_last) {

		bitoffset = c - font->index1_first;

		bitoffset *= font->bits_index;

		} else if (c >= font->index2_first && c <= font->index2_last) {

		bitoffset = c - font->index2_first + font->index1_last - font->index1_first + 1;

		bitoffset *= font->bits_index;

		} else if (font->unicode) {

		return(0); // TODO: implement sparse unicode

		} else {

		return(0);

	}

	data = font->data + fetchbits_unsigned(font->index, bitoffset, font->bits_index);

	uint32_t encoding = fetchbits_unsigned(data, 0, 3);

	if (encoding != 0) return(0);

	uint32_t width = fetchbits_unsigned(data, 3, font->bits_width);

	bitoffset = font->bits_width + 3;

	uint32_t height = fetchbits_unsigned(data, bitoffset, font->bits_height);

	bitoffset += font->bits_height;


	int32_t xoffset = fetchbits_signed(data, bitoffset, font->bits_xoffset);

	bitoffset += font->bits_xoffset;

	int32_t yoffset = fetchbits_signed(data, bitoffset, font->bits_yoffset);

	bitoffset += font->bits_yoffset;

	uint32_t delta = fetchbits_unsigned(data, bitoffset, font->bits_delta);
	bitoffset += font->bits_delta;

	// horizontally, we draw every pixel, or none at all
	if (cursor_x < 0) cursor_x = 0;

	int32_t origin_x = cursor_x + xoffset;

	if (origin_x < 0) {
		cursor_x -= xoffset;
		origin_x = 0;

	}

	if (origin_x + (int)width > ILI9341_DEFAULT_WIDTH) {

		if (!1) return(0);

		origin_x = 0;

		if (xoffset >= 0) {
			cursor_x = 0;

			} else {
			cursor_x = -xoffset;
		}

		cursor_y += font->line_space;
	}

	if (cursor_y >= ILI9341_DEFAULT_HEIGHT) return(0);
	cursor_x += delta;

	// vertically, the top and/or bottom can be clipped
	int32_t origin_y = cursor_y + font->cap_height - height - yoffset;

	// TODO: compute top skip and number of lines
	int32_t linecount = height;

	uint32_t y = origin_y;

	while (linecount) {

		uint32_t b = fetchbit(data, bitoffset++);

		if (b == 0) {

			uint32_t x = 0;

			do {

				uint32_t xsize = width - x;

				if (xsize > 32) xsize = 32;

				uint32_t bits = fetchbits_unsigned(data, bitoffset, xsize);

				drawFontBits(bits, xsize, origin_x + x, y, 1);

				bitoffset += xsize;

				x += xsize;

			} while (x < width);

			y++;

			linecount--;

			} else {

			uint32_t n = fetchbits_unsigned(data, bitoffset, 3) + 2;

			bitoffset += 3;

			uint32_t x = 0;

			do {

				uint32_t xsize = width - x;

				if (xsize > 32) xsize = 32;

				uint32_t bits = fetchbits_unsigned(data, bitoffset, xsize);

				drawFontBits(bits, xsize, origin_x + x, y, n);

				bitoffset += xsize;

				x += xsize;

			} while (x < width);

			y += n;

			linecount -= n;
		}
	}
	return(width);
}


void drawFontString(char * cstring, int x, int y, ILI9341_t3_font_t * font){
	
	int test;
	
	while(* cstring != (int)NULL){
		test = drawFontChar(*cstring++, x, y, font); x += test + 3;
	}
}

void drawFontInt(signed long data, int x, int y, ILI9341_t3_font_t * font){
	
	volatile unsigned char interger_size = 15, negative_flag = false;
	
	volatile unsigned int i_gt = interger_size;
	char data_dump[interger_size];
	
	if(data < 0){
	data = data * -1; negative_flag = true;}
	
	
	data_dump[interger_size] = '\0';
	do{
		data_dump[--i_gt] = '0' + (data % 10);
		data /= 10;
	}while(data);
	
	if(negative_flag == true){
		data_dump[--i_gt] = '-';
	}
	
	drawFontString(&data_dump[i_gt], x, y, font);
}


void drawFontBits(uint32_t bits, uint32_t numbits, uint32_t x, uint32_t y, uint32_t repeat){
#if 1

	if (bits == 0) return;
	int w = 0;

	do {

		uint32_t x1 = x;
		uint32_t n = numbits;

		ili9341_send_command(ILI9341_PASET); // Row addr set

		ili9341_send_byte(y >> 8);
		ili9341_send_byte(y & 0xFF);;   // YSTART

		ili9341_send_byte(y >> 8);
		ili9341_send_byte(y & 0xFF);;   // XSTART
		do {
			n--;
			if (bits & (1 << n)) {
				w++;
			}
			else if (w > 0) {
				ili9341_send_command(ILI9341_CASET); // Column addr set

				ili9341_send_byte((x1 - w) >> 8);
				ili9341_send_byte((x1 - w) & 0xFF);;   // XSTART

				ili9341_send_byte((x1) >> 8);
				ili9341_send_byte((x1) & 0xFF);;   // XSTART

				ili9341_send_command(ILI9341_RAMWR);

				while (w-- > 1) { // draw line
					ili9341_send_byte(ILI9341_WHITE >> 8);
					ili9341_send_byte(ILI9341_WHITE & 0xFF);
				}
				ili9341_send_byte(ILI9341_WHITE >> 8);
				ili9341_send_byte(ILI9341_WHITE & 0xFF);

			}
			x1++;
		} while (n > 0);

		if (w > 0) {
			ili9341_send_command(ILI9341_CASET); // Column addr set

			ili9341_send_byte((x1 - w) >> 8);
			ili9341_send_byte((x1 - w) & 0xFF);   // XSTART

			ili9341_send_byte(x1 >> 8);
			ili9341_send_byte(x1 & 0xFF);  // XEND

			ili9341_send_command(ILI9341_RAMWR);

			while (w-- > 1) { //draw line
				ili9341_send_byte(ILI9341_WHITE >> 8);
				ili9341_send_byte(ILI9341_WHITE & 0xFF);
			}
			ili9341_send_byte(ILI9341_WHITE >> 8);
			ili9341_send_byte(ILI9341_WHITE & 0xFF);
		}
		y++;
		repeat--;
	} while (repeat);
	#endif
}

void drawString(int16_t x, int16_t y, char *c, uint16_t fgcolor, uint16_t bgcolor, uint8_t size){
	
	while(*c != (int)NULL){
		drawChar(x, y, *c++, fgcolor, bgcolor, size); x += size * 6;
	}
}

void drawInt(uint16_t x, uint16_t y, signed long int integer, uint16_t fgcolor, uint16_t bgcolor, uint16_t size){
	
	volatile unsigned char interger_size = 15, negative_flag = false;
	
	volatile unsigned int i_gt = interger_size;
	char data_dump[interger_size];
	
	if(integer < 0){
	integer = integer * -1; negative_flag = true;}
	
	
	data_dump[interger_size] = '\0';
	do{
		data_dump[--i_gt] = '0' + (integer % 10);
		integer /= 10;
	}while(integer);
	
	if(negative_flag == true){
		data_dump[--i_gt] = '-';
	}
	
	drawString(x, y, &data_dump[i_gt], fgcolor, bgcolor, size);
}


void drawPercentage(uint16_t x, uint16_t y, signed long int integer, uint16_t fgcolor, uint16_t bgcolor, uint16_t size){
	
	volatile unsigned char interger_size = 15, negative_flag = false;
	
	volatile unsigned int i_gt = interger_size;
	char data_dump[interger_size];
	
	if(integer < 0){
	integer = integer * -1; negative_flag = true;}
	
	
	data_dump[interger_size] = '\0';
	data_dump[interger_size - 1] = '%';
	
	--i_gt;
	
	do{
		data_dump[--i_gt] = '0' + (integer % 10);
		integer /= 10;
	}while(integer);
	
	if(negative_flag == true){
		data_dump[--i_gt] = '-';
	}
	
	drawString(x, y, &data_dump[i_gt], fgcolor, bgcolor, size);
}