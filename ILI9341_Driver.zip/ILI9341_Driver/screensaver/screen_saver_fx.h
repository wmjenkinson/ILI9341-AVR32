/*This file has been prepared for Doxygen automatic documentation generation.*/
/*! \file *********************************************************************
 *
 * \brief 3D Cube Demo example use with 3D lib
 * This is an example of a 3D cube containing the logo AVR32
 *
 * - Compiler:           IAR EWAVR32 and GNU GCC for AVR32
 * - Supported devices:  All AVR32 devices with GPIO.
 * - AppNote:
 *
 * \author               Atmel Corporation: http://www.atmel.com \n
 *                       Support and FAQ: http://support.atmel.no/
 *
 *****************************************************************************/

/* Copyright (C) 2006-2008, Atmel Corporation All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice,
 * this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 * this list of conditions and the following disclaimer in the documentation
 * and/or other materials provided with the distribution.
 *
 * 3. The name of ATMEL may not be used to endorse or promote products derived
 * from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY ATMEL ``AS IS'' AND ANY EXPRESS OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE EXPRESSLY AND
 * SPECIFICALLY DISCLAIMED. IN NO EVENT SHALL ATMEL BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR serviceS;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

/*!
 * \mainpage
 * \section section1 Description
 *   This application is a 3D Implementation on UC3B \n
 *   It runs on an EVK1101 board with the add-on board. \n
 *   The main source files are :
 *
 *          - \ref application.c        Main loop
 *          - \ref 3dengine.c           3D Graphic Engine
 *          - \ref lcd_nokia.c          Low Level Layer for LCD display
 *
 *
 * \section section2 Configuration
 * The configuration of the application is stored in different files :
 *
 *          - \ref conf_3Dcube.h              Contains the configuration of the application
 *
 * \section section3 Main Peripheral Use
 *   - SPI is used for LCD Display
 *
 * \section section4 User Manual
 *   - See the associated application note available at http://www.atmel.com
 *
 * \subsection subsection1 List of Material
 *   - EVK1101 (UC3B) + EVK1101 Extension Board.
 *
 * \section section5 Supported Compiler
 *  - AVR32-GCC 4.2.2 - atmel 1.0.4 with AVR32 GNU TOOLCHAIN 2 beta 5.
 *  - IAR C/C++ Compiler for Atmel AVR32 2.21B/W32 (2.21.2.3)
 */

//_____  I N C L U D E S ___________________________________________________
#include <string.h>
#include <math.h>

#include "Darkness_Kernel/Drivers/ILI9341_Driver/ili9341gfx.h"

#include "lcd_nokia.h"
#include "3dengine.h"
#include "raster.h"
#include "conf_3Dcube.h"
#include "picture_objects.h"
#include "Darkness_Kernel/Drivers/ILI9341_Driver/ili9341gfx.h"
#include "Darkness_Kernel/watchdog.h"



int rotation_axes_cpt = 1;		 //!< Rotation Axes Speed Reference
extern int Face_to_prints[3];    //!< Faces Reference
extern int Number_Face_to_print; //!< Number of Face to Display

char *RASTER;					 //!< LCD Display Screen Content
unsigned char mycolor = White;   //!< Current Color

void setup(void);
void setup(void){
	RASTER = api_malloc(sizeof(char) * (SCR_WIDE * SCR_HEIGHT));
}

extern void cube(void);
void cube(void)
{

  int teta = 0;
  int MYTSFMATR[9];

  // First init of the rotation matrix
  mrot_C8_FULL_FFIX(MYTSFMATR, teta, 0x5A82, 0x5A82, 0);
 
  reset_Raster(RASTER);
  
  fillScreen(ILI9341_WHITE);
  
  
  extern char anykey(void);
  while(anykey() != SEM_ACK){
        
        //modify rotation axes
      	switch (0)
      	{
      		// Rotation Axes on x,y
          case 0:
              mrot_C8_FULL_FFIX(MYTSFMATR, teta, 0x5A82, 0x5A82, 0);
      		break;
      		// Rotation Axes on y,-z
          case 1 :
              mrot_C8_FULL_FFIX(MYTSFMATR, teta, 0, 0x5A82,-0x5A82);
      		break;
          // Rotation Axes on y,z
          case 2 :
              mrot_C8_FULL_FFIX(MYTSFMATR, teta, 0,0x5A82 , 0x5A82);
          break;
          // Rotation Axes on -x,y,z
          case 3 :
              mrot_C8_FULL_FFIX(MYTSFMATR, teta, -0x49E6, 0x49E6, 0x49E6);
          break;
          // Rotation Axes on x,z
          case 4 :
              mrot_C8_FULL_FFIX(MYTSFMATR, teta, 0x5A82, 0, 0x5A82);
          break;
          // Rotation Axes on x,-y,-z
          case 5 :
              mrot_C8_FULL_FFIX(MYTSFMATR, teta, 0x49E6, -0x49E6, -0x49E6);
          break;
          // Rotation Axes on -z
          case 6 :
              mrot_C8_FULL_FFIX(MYTSFMATR, teta, 0, 0, 0x8000);
          break;
          // Default : It is the Identity Matrix
          default:
            MYTSFMATR[0] = 1;MYTSFMATR[1] = 0;MYTSFMATR[2] = 0;
            MYTSFMATR[3] = 0;MYTSFMATR[4] = 1;MYTSFMATR[5] = 0;
            MYTSFMATR[6] = 0;MYTSFMATR[7] = 0;MYTSFMATR[8] = 1;
      		break;
        }
        
		// Teta Update: Update step between every rotation axes
        // Bigger is the step and Faster is the rotation
        teta += 3;
        if(teta>=240)
        {
              teta=0;
        }
		
		
		drawString(35, 44, (char *)&NMEA_GPRMC.UTC_Time[0], ILI9341_BLUE, ILI9341_WHITE, 2);
		
		
		ili9341_set_top_left_limit(75, 75);
		ili9341_set_bottom_right_limit(75 + SCR_HEIGHT - 1, 75 + SCR_WIDE);
		
		int i = 0, color; ili9341_send_command(0x2c);
		
		while (i != (SCR_WIDE * SCR_HEIGHT)) {
			
			if(RASTER[i] == 0xff)color = 0xffff;
			else{
				
				char Red = ((RASTER[i] & 0b11100000) >> 5);
				char Grn = ((RASTER[i] & 0b00011100) >> 2);
				char Blu = ((RASTER[i] & 0b00000011));
				
				color = Red << 13; color |= Grn << 8; color |= Blu << 3; 
			}
			ili9341_send_byte(color >> 8);
			ili9341_send_byte(color);
			
			i++;
		}
		
        // Clear Display Buffer for next compute step
        reset_Raster(RASTER);

        // Compute 3D Transformation with last MATRIX value
        // Input buffer : centers / Output buffer : tmpcenters
        transforme_C8_FFIX((OBJ3D_C8_FFIX *)&centers, (OBJ3D_C8_FFIX *)&tmpcenters, (int *)MYTSFMATR);

        // Compute zBuffer Transformation in order to optimize display
        update_faces();

        for(int i = 0; i < Number_Face_to_print; i++)
        {
          // Test if it is a face to display so a Picture
          if (cube_logoavr32[Face_to_prints[i]])
          {
              transforme_C8_FFIX(cube_logoavr32[Face_to_prints[i]], tmpcube_logoavr32[Face_to_prints[i]], MYTSFMATR);
              draw_image_raster_bmp(tmpcube_logoavr32[Face_to_prints[i]], AVR32_COLOR, &RASTER[0]);
          }
          // Else Display Cube Transformation
          transforme_C8_FFIX((OBJ3D_C8_FFIX *)&of[Face_to_prints[i]], (OBJ3D_C8_FFIX *)&tmpof[Face_to_prints[i]], (int *)MYTSFMATR);
          draw_image_raster(&tmpof[Face_to_prints[i]], MESH_COLOR, &RASTER[0]);
         }
    }
	extern void refresh_dsp(void); refresh_dsp();
}
