// https://github.com/PaulStoffregen/ILI9341_t3
// http://forum.pjrc.com/threads/26305-Highly-optimized-ILI9341-(320x240-TFT-color-display)-library

/***************************************************
  This is our library for the Adafruit ILI9341 Breakout and Shield
  ----> http://www.adafruit.com/products/1651

  Check out the links above for our tutorials and wiring diagrams
  These displays use SPI to communicate, 4 or 5 pins are required to
  interface (RST is optional)
  Adafruit invests time and resources providing this open source code,
  please support Adafruit and open-source hardware by purchasing
  products from Adafruit!

  Written by Limor Fried/Ladyada for Adafruit Industries.
  MIT license, all text above must be included in any redistribution

 **************************************************
//Additional graphics routines by Tim Trzepacz, SoftEgg LLC added December 2015
//(And then accidentally deleted and rewritten March 2016. Oops!)
//Gradient support 
//----------------
//		fillRectVGradient	- fills area with vertical gradient
//		fillRectHGradient	- fills area with horizontal gradient
//		fillScreenVGradient - fills screen with vertical gradient
// 	fillScreenHGradient - fills screen with horizontal gradient

//Additional Color Support
//------------------------
//		color565toRGB		- converts 565 format 16 bit color to RGB
//		color565toRGB14		- converts 16 bit 565 format color to 14 bit RGB (2 bits clear for math and sign)
//		RGB14tocolor565		- converts 14 bit RGB back to 16 bit 565 format color

//Low Memory Bitmap Support
//-------------------------
// 		writeRect8BPP - 	write 8 bit per pixel paletted bitmap
// 		writeRect4BPP - 	write 4 bit per pixel paletted bitmap
// 		writeRect2BPP - 	write 2 bit per pixel paletted bitmap
// 		writeRect1BPP - 	write 1 bit per pixel paletted bitmap

//TODO: transparent bitmap writing routines for sprites

//String Pixel Length support 
//---------------------------
//		strPixelLen			- gets pixel length of given ASCII string
*/


#ifndef GFX
#define GFX

#include "stdint.h"
#include "ASF\common\components\display\ili9341\ili9341.h"

// Color definitions
#define ILI9341_BLACK       0x0000      /*   0,   0,   0 */
#define ILI9341_NAVY        0x000F      /*   0,   0, 128 */
#define ILI9341_DARKGREEN   0x03E0      /*   0, 128,   0 */
#define ILI9341_DARKCYAN    0x03EF      /*   0, 128, 128 */
#define ILI9341_MAROON      0x7800      /* 128,   0,   0 */
#define ILI9341_PURPLE      0x780F      /* 128,   0, 128 */
#define ILI9341_OLIVE       0x7BE0      /* 128, 128,   0 */
#define ILI9341_LIGHTGREY   0xC618      /* 192, 192, 192 */
#define ILI9341_DARKGREY    0x7BEF      /* 128, 128, 128 */
#define ILI9341_BLUE        0x001F      /*   0,   0, 255 */
#define ILI9341_GREEN       0x07E0      /*   0, 255,   0 */
#define ILI9341_CYAN        0x07FF      /*   0, 255, 255 */
#define ILI9341_RED         0xF800      /* 255,   0,   0 */
#define ILI9341_MAGENTA     0xF81F      /* 255,   0, 255 */
#define ILI9341_YELLOW      0xFFE0      /* 255, 255,   0 */
#define ILI9341_WHITE       0xFFFF      /* 255, 255, 255 */
#define ILI9341_ORANGE      0xFD20      /* 255, 165,   0 */
#define ILI9341_GREENYELLOW 0xAFE5      /* 173, 255,  47 */
#define ILI9341_PINK        0xF81F



#define ILI9341_TFTWIDTH  240
#define ILI9341_TFTHEIGHT 320

#define ILI9341_NOP     0x00
#define ILI9341_SWRESET 0x01
#define ILI9341_RDDID   0x04
#define ILI9341_RDDST   0x09

#define ILI9341_SLPIN   0x10
#define ILI9341_SLPOUT  0x11
#define ILI9341_PTLON   0x12
#define ILI9341_NORON   0x13

#define ILI9341_RDMODE  0x0A
#define ILI9341_RDMADCTL  0x0B
#define ILI9341_RDPIXFMT  0x0C
#define ILI9341_RDIMGFMT  0x0D
#define ILI9341_RDSELFDIAG  0x0F
#define ILI9341_INVOFF  0x20
#define ILI9341_INVON   0x21
#define ILI9341_GAMMASET 0x26
#define ILI9341_DISPOFF 0x28
#define ILI9341_DISPON  0x29

#define ILI9341_CASET   0x2A
#define ILI9341_PASET   0x2B
#define ILI9341_RAMWR   0x2C
#define ILI9341_RAMRD   0x2E


#define ILI9341_PTLAR    0x30
#define ILI9341_MADCTL   0x36
#define ILI9341_VSCRSADD 0x37
#define ILI9341_PIXFMT   0x3A

#define ILI9341_FRMCTR1 0xB1
#define ILI9341_FRMCTR2 0xB2
#define ILI9341_FRMCTR3 0xB3
#define ILI9341_INVCTR  0xB4
#define ILI9341_DFUNCTR 0xB6

#define ILI9341_PWCTR1  0xC0
#define ILI9341_PWCTR2  0xC1
#define ILI9341_PWCTR3  0xC2
#define ILI9341_PWCTR4  0xC3
#define ILI9341_PWCTR5  0xC4

#define ILI9341_VMCTR1  0xC5
#define ILI9341_VMCTR2  0xC7

#define ILI9341_RDID1   0xDA
#define ILI9341_RDID2   0xDB
#define ILI9341_RDID3   0xDC
#define ILI9341_RDID4   0xDD

#define ILI9341_GMCTRP1 0xE0
#define ILI9341_GMCTRN1 0xE1

/* font index size: 119 bytes */
typedef struct {
	const unsigned char *index;
	const unsigned char *unicode;
	const unsigned char *data;
	unsigned char version;
	unsigned char reserved;
	unsigned char index1_first;
	unsigned char index1_last;
	unsigned char index2_first;
	unsigned char index2_last;
	unsigned char bits_index;
	unsigned char bits_width;
	unsigned char bits_height;
	unsigned char bits_xoffset;
	unsigned char bits_yoffset;
	unsigned char bits_delta;
	unsigned char line_space;
	unsigned char cap_height;
} ILI9341_t3_font_t;

ILI9341_t3_font_t * font;

#ifndef swap
#define swap(a, b) { typeof(a) t = a; a = b; b = t; }
#endif

extern void setAddr(int, int, int, int);

extern void Pixel(int16_t x, int16_t y, uint16_t color);

extern void HLine(int16_t x, int16_t y, int16_t w, uint16_t color);

extern void VLine(int16_t x, int16_t y, int16_t h, uint16_t color);

extern uint16_t RGB14tocolor565(int16_t r, int16_t g, int16_t b);

extern uint16_t color565(uint8_t r, uint8_t g, uint8_t b);

extern void color565toRGB(uint16_t color, uint8_t *r, uint8_t *g, uint8_t *b);

extern void color565toRGB14(uint16_t color, int16_t *r, int16_t *g, int16_t *b);

extern void pushColor(uint16_t color);

extern void drawPixel(int16_t x, int16_t y, uint16_t color);

extern void drawFastVLine(int16_t x, int16_t y, int16_t h, uint16_t color);

extern void drawFastHLine(int16_t x, int16_t y, int16_t w, uint16_t color);

extern void fillRect(int16_t x, int16_t y, int16_t w, int16_t h, uint16_t color);

extern void fillRectVGradient(int16_t x, int16_t y, int16_t w, int16_t h, uint16_t color1, uint16_t color2);

extern void fillRectHGradient(int16_t x, int16_t y, int16_t w, int16_t h, uint16_t color1, uint16_t color2);

extern void setRotation(uint8_t m);

extern void setScroll(uint16_t offset);

extern void invertDisplay(Bool i);

extern void fillScreen(uint16_t color);

extern void fillScreenVGradient(uint16_t color1, uint16_t color2);

extern void fillScreenHGradient(uint16_t color1, uint16_t color2);

extern void drawCircle(int16_t x0, int16_t y0, int16_t r, uint16_t color);

extern void drawCircleHelper( int16_t x0, int16_t y0, int16_t r, uint8_t cornername, uint16_t color);

extern void fillCircleHelper(int16_t x0, int16_t y0, int16_t r,uint8_t cornername, int16_t delta, uint16_t color);

extern void fillCircle(int16_t x0, int16_t y0, int16_t r,uint16_t color);

extern void drawLine(int16_t x0, int16_t y0, int16_t x1, int16_t y1, uint16_t color);

extern void drawRect(int16_t x, int16_t y, int16_t w, int16_t h, uint16_t color);

extern void drawRoundRect(int16_t x, int16_t y, int16_t w, int16_t h, int16_t r, uint16_t color);

extern void fillRoundRect(int16_t x, int16_t y, int16_t w, int16_t h, int16_t r, uint16_t color);

extern void drawTriangle(int16_t x0, int16_t y0, int16_t x1, int16_t y1, int16_t x2, int16_t y2, uint16_t color);

extern void fillTriangle ( int16_t x0, int16_t y0, int16_t x1, int16_t y1, int16_t x2, int16_t y2, uint16_t color);

extern size_t write(uint8_t c);

extern void drawChar(int16_t x, int16_t y, unsigned char c, uint16_t fgcolor, uint16_t bgcolor, uint8_t size);

extern uint32_t fetchbit(const uint8_t *p, uint32_t index);

extern uint32_t fetchbits_unsigned(const uint8_t *p, uint32_t index, uint32_t required);

extern uint32_t fetchbits_signed(const uint8_t *p, uint32_t index, uint32_t required);

extern int  drawFontChar(char c, int, int, ILI9341_t3_font_t *);
extern void drawFontString(char * c, int, int, ILI9341_t3_font_t *);
extern void drawFontInt(signed long int, int, int, ILI9341_t3_font_t *);

extern void drawFontBits(uint32_t bits, uint32_t numbits, uint32_t x, uint32_t y, uint32_t repeat);

extern void drawString(int16_t x, int16_t y, char *c, uint16_t fgcolor, uint16_t bgcolor, uint8_t size);

extern void drawInt(uint16_t x, uint16_t y, signed long int, uint16_t fgcolor, uint16_t bgcolor, uint16_t size);
extern void drawPercentage(uint16_t x, uint16_t y, signed long int integer, uint16_t fgcolor, uint16_t bgcolor, uint16_t size);

extern void console_text(char * );
extern char * text_prompt(uint16_t fgcolor, uint16_t bgcolor, uint8_t size);
#endif /* INCFILE1_H_ */