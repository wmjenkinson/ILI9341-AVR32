/*
 * application_mode_routine.h
 *
 * Created: 16/06/2017 13:24:19
 *  Author: William
 */ 
/*
 * Copyright (c) 2017 Queens University Belfast.
 * All rights reserved. 
 * 
 * Redistribution and use in source and binary forms, with or without modification, 
 * are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice,
 *    this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 * 3. The name of the author may not be used to endorse or promote products
 *    derived from this software without specific prior written permission. 
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR IMPLIED 
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF 
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT 
 * SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT 
 * OF SUBSTITUTE GOODS OR serviceS; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS 
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN 
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING 
 * IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY 
 * OF SUCH DAMAGE.
 *
 * This file is part of the Darkness Real-time Kernel.
 * 
 * Author: William Jenkinson <wm.jenkinson@hotmail.com */
/*
 * ili9341.h
 *
 * Created: 23/02/2016 00:57:31
 *  Author: wmjen
 */ 


#ifndef ILI9341_H_
#define ILI9341_H_

void ILI9341Display(void);

#include "Darkness_Kernel/Buffers/buffer_shorts.h"
#include "Darkness_Kernel/delay_core.h"

#include "Darkness_Kernel/Drivers/GPS/NMEA Architecture.h"
#include "Darkness_Kernel\Drivers/ILI9341_Driver/ili9341gfx.h"
#include "Darkness_kernel\drivers\ILI9341_Driver\WallPapers\Darkness.h"
#include "Darkness_Kernel\drivers\ILI9341_Driver\screensaver\screen_saver_fx.h"
#include "Darkness_Kernel\Drivers\KeyBoard\keyboard.h"
#include "Darkness_Kernel\watchdog.h"
#include "Darkness_Kernel\Drivers\ILI9341_Driver\WallPapers\menu.h"

#include "Darkness_Kernel\Drivers\ILI9341_Driver\Fractals\fractals.h"
#include "Darkness_Kernel/Drivers/ILI9341_Driver/Fractals/buddahbrot.h"

#include "Darkness_Kernel/Drivers/ILI9341_Driver/terminal/terminal.h"

char * comsole_cmd;

/** Number of pixels for full screen */
#define TOTAL_PIXELS ((uint32_t)ILI9341_DEFAULT_WIDTH * ILI9341_DEFAULT_HEIGHT)

extern const unsigned char glcdfont[];
extern volatile unsigned char key_detected;
void parse_ip_addr(char *, char *);
void parse_ip_addr(char * comsole_cmd, char * ip){
	
	
	for(int i = 0; i < 4; i++){
		
		* ip = ((* comsole_cmd++ - 0x30) * 100);
		
		if((* comsole_cmd >= '0') && (* comsole_cmd <= '9')){
			* ip += ((* comsole_cmd++ - 0x30) * 10);

			
			if((* comsole_cmd >= '0') && (* comsole_cmd <= '9')){
				* ip += (* comsole_cmd - 0x30); comsole_cmd += 2; }
			
			
			else{
				* ip = * ip / 10; comsole_cmd++; }
		}
		else{
			* ip = * ip / 100; comsole_cmd++; }
		
		ip++;
	}
}

Bool adc_reading_request;
struct ipc_mailbox_object * adc_link = NULL;

struct ipc_buffer_object * get_adc(void);
struct ipc_buffer_object * get_adc(void){
	
	if(adc_link == NULL)
		adc_link = api_create_mailbox();
	
	adc_reading_request = true;
	return((struct ipc_buffer_object *)api_recieve_mail(adc_link, from_IRQ, 0));
}

extern void Pixel(int16_t x, int16_t y, uint16_t color);

void draw_graph(void);
void draw_graph(void){
	
	extern char anykey(void);
	struct ipc_buffer_object * graph = get_adc();
	
	fillScreen(ILI9341_LIGHTGREY);
	
	short y_old, y_new;
	unsigned char status = 0;
	
	y_old = api_buffer_accept16(graph, &status);
	y_new = api_buffer_accept16(graph, &status);
	
	drawLine(0 + 32, 120, 256 + 32, 120, ILI9341_RED);
	drawLine(128 + 32, 0, 128 + 32, 240, ILI9341_RED);
		
	drawString(5, 125, "cord-x = 0", ILI9341_WHITE, ILI9341_LIGHTGREY, 1);
	drawString(250, 125, "cord-x = 256", ILI9341_WHITE, ILI9341_LIGHTGREY, 1);
	
	drawString(128, 120, "cord-y = 0", ILI9341_WHITE, ILI9341_LIGHTGREY, 1);
	drawString(128, 230, "cord-y = -32767", ILI9341_WHITE, ILI9341_LIGHTGREY, 1);
	drawString(128, 10, "cord-y = 32767", ILI9341_WHITE, ILI9341_LIGHTGREY, 1);
	

	y_old = y_old * -1;
	y_old = y_old / 273;
	y_old += 120;

	y_new = y_new * -1;
	y_new = y_new / 273;
	y_new += 120;
	
	
		
	int i = 1;	
	while(i < 256){
		
		drawLine(i - 1 + 32, y_old, i  + 32, y_new, ILI9341_ORANGE);
		y_old = y_new;
		
		y_new = api_buffer_accept16(graph, &status);
	
		y_new = y_new * -1;
		y_new = (y_new / 273);
		y_new += 120;
		
		
		i++;
	}
	
	api_buffer_flush16(graph);
	while(anykey() != SEM_ACK);
	refresh_dsp();
}

void draw_ram(void);
void draw_ram(void){
	
	extern unsigned char * display_ram, * return_dsp_ram_addr;
	
	display_ram = return_dsp_ram_addr;
	
	unsigned short pixel;
	
	for(int x = 0; x < 320; x++){
		for(int y = 0; y < 240; y++){
			
			pixel = (* display_ram << 8);	display_ram++;
			pixel |= * display_ram;			display_ram++;
			
			drawPixel(x, y, pixel);
		}
	}
	
	while(true){
		extern char anykey(void); if(anykey() == SEM_ACK)
		break;
	}
	extern void refresh_dsp(void); refresh_dsp();
}

void ping_ld(void);
void ping_ld(void){
		
	int n = 1, l = 32;
	
	char * duplicate; duplicate = comsole_cmd;
	 
	if(memcmp(comsole_cmd, "ping", 4) == false){
		
		for(int i = 0; i < 3; i++){
			
			while((* comsole_cmd != '\0') && (* comsole_cmd != '-'))
				comsole_cmd++;
			
			if(* comsole_cmd == '-'){
				if(*(comsole_cmd + 1) == 'n'){
					n = (*(comsole_cmd + 3) - 0x30) * 100;
					if((*(comsole_cmd + 4) >= '0') && (*(comsole_cmd + 4) <= '9')){
						n = n + (((*(comsole_cmd + 4)) - 0x30) * 10);
						if((*(comsole_cmd + 5) >= '0') && (*(comsole_cmd + 5) <= '9')){
							n = n + (((*(comsole_cmd + 5)) - 0x30));
						}
						else{
							n = n / 10;
						}
					}
					else{
						n = n / 100;
					}
				}
				else{
					if(*(comsole_cmd + 1) == 'l'){
						l = (*(comsole_cmd + 3) - 0x30) * 100;
						if((*(comsole_cmd + 4) >= '0') && (*(comsole_cmd + 4) <= '9')){
							l = l + ((*(comsole_cmd + 4)) - 0x30) * 10;
							if((*(comsole_cmd + 5) >= '0') && (*(comsole_cmd + 5) <= '9')){
								l = l + *(comsole_cmd + 5) - 0x30;
							}
							else{
								l = l / 10;
							}
						}
						else{
							l = l / 100;
						}
					}
				}
				comsole_cmd++;			
			}
			else if(*comsole_cmd == '\0'){
			
				int dots = 0;
				comsole_cmd = duplicate;
				
				while(*comsole_cmd != '\0'){
					if(*comsole_cmd == '.')
						dots++;
					comsole_cmd++;
				}
				if(dots == 3){
					comsole_cmd = duplicate;
					while(*comsole_cmd != '.')
						comsole_cmd++;
					comsole_cmd = comsole_cmd - 3;
						
					char ip[5];
					
					parse_ip_addr(comsole_cmd, &ip[0]);
					
					
					
					for(int i = 0; i < n; i++){
						extern void send_ping_request(unsigned char *, int, char[4]); send_ping_request(NULL, l, ip);
						api_delay_task(api_ownID(), 1000);
					}
				}
				return;
			}
			comsole_cmd++;
		}
	}
}


void ILI9341Display(void){
	
	// Setup Screensaver
	extern void setup(void); setup();
			
	/* Make sure to initialize the display controller */
	ili9341_init();

	extern const ILI9341_t3_font_t Arial_24;
	
	drawFontString("DARKNESS", 52, 90, (ILI9341_t3_font_t *)&Arial_24);
	delay_s(10);
	
	fillScreen(ILI9341_BLACK);
	
	extern void build_arp_list(void); build_arp_list();
	
	load_program(build_arp_list, "arp");
	load_program(cube, "3d cube");
	load_program(mandlebrot, "traditional");
	load_program(buddahbrot_main, "budda");		
	load_program(julia_set, "julia set");
	load_program(tetration, "tetration set");
	load_program(draw_graph, "graph");
	load_program(draw_ram, "draw");
	load_program(DoFractal, "mandlebrot");
	load_program(ping_ld, "ping");
	
	
	while(true){
		comsole_cmd = text_prompt(ILI9341_WHITE, ILI9341_BLACK, 2);
		char * duplicate; duplicate = comsole_cmd; 
		 
		
		if(program_active(comsole_cmd)){
			get_program(duplicate);
		}
	}
}
#endif /* ILI9341_H_ */