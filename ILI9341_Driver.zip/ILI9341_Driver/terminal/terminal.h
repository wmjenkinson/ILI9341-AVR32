/*
 * application_mode_routine.h
 *
 * Created: 16/06/2017 13:24:19
 *  Author: William
 */ 
/*
 * Copyright (c) 2017 Queens University Belfast.
 * All rights reserved. 
 * 
 * Redistribution and use in source and binary forms, with or without modification, 
 * are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice,
 *    this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 * 3. The name of the author may not be used to endorse or promote products
 *    derived from this software without specific prior written permission. 
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR IMPLIED 
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF 
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT 
 * SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT 
 * OF SUBSTITUTE GOODS OR serviceS; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS 
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN 
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING 
 * IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY 
 * OF SUCH DAMAGE.
 *
 * This file is part of the Darkness Real-time Kernel.
 * 
 * Author: William Jenkinson <wm.jenkinson@hotmail.com */
/*
 * terminal.h
 *
 * Created: 16/04/2017 23:17:07
 *  Author: wmjen
 */ 
#ifndef TERMINAL_H_
#define TERMINAL_H_


#include "Darkness_Kernel/Drivers/ILI9341_Driver/ili9341gfx.h"
#include "Darkness_Kernel/Drivers/KeyBoard/keyboard.h"

#include "string.h"

extern void refresh_dsp(void);

char link_char;

struct program_detials{
	
	void * program;
	char   name[20];
	
	struct program_detials * next;
	struct program_detials * prev;
};

struct boot_record{
	
	struct program_detials * first_program;
	int nr;
}* program_list = NULL;

static void add_program_node(struct program_detials * program){
	
	if( program_list->nr++ == 0){
		program_list->first_program	= program;
		program->next				= program;
		program->prev				= program;
	}
	else{
		program->next = program_list->first_program;
		program->prev = program_list->first_program->prev;
		
		program_list->first_program->prev->next = program;
		program_list->first_program->prev = program;
	}
}

/*
static void remove_program_node(struct program_detials * program){
	
	
	if( program_list->nr == 1){
		program_list->nr = 0;
	}
	else
	{
		program_list->nr--;
		if(program_list->first_program == program){
			program_list->first_program = program->next;
		}
		program->prev->next = program->next;
		program->next->prev = program->prev;
	}
}
*/
Bool get_program(char * name); Bool get_program(char * name){
	
	char * duplicated; duplicated = name;
	
	struct program_detials * procedure = program_list->first_program;
	
	extern void ping_ld(void);
	if(memcmp(name, "ping", 4) == false){
		ping_ld(); return true;
	}
	
	else{
		
		char size = 0;
		while(* name != '\r'){
			size++; name++; }
	
		if(size == 0)
			return false;
		
		void (*procedure_exe)(void);
		
		for(int i = 0; i < program_list->nr; i++){
			
			if(memcmp(duplicated, &procedure->name[0], size) == false){
				
				{
					barrier();
				
					procedure_exe = procedure->program; procedure_exe();
					return true;
				}
			}
			
			procedure = procedure->next;
		}
		return false;
	}
}
Bool program_active(char * name);
Bool program_active(char * name){
	
	char * duplicated; duplicated = name;
	
	struct program_detials * program = program_list->first_program;
	
	if(memcmp(name, "ping ", 5) == false)
		return true;
	
	char size = 0;
	while(* name != '\r'){
		size++; name++; }
	
	if(size == 0)
		return false;
	
	
	for(int i = 0; i < program_list->nr; i++){
		
		if(memcmp(duplicated, &program->name[0], size) == false)
			return true;
		
		program = program->next;
	}
	return false;
}


void load_program(void *, char *);
void load_program(void * program, char * name){
	
	char * duplicate; duplicate = name;
	
	if(program_list == NULL)
		program_list = api_malloc(sizeof(struct boot_record));

	struct program_detials * program_settings = api_malloc(sizeof(struct program_detials));
	
	program_settings->program = program;
	
	int size = 0;
	while(* name != '\0'){
		size++; name++; }
	
	int i = 0;
	while (i < size){
		program_settings->name[i++] = * duplicate; duplicate++; }
	
	program_settings->name[i++] = '\0';
	add_program_node(program_settings);
}

char * text_prompt(uint16_t, uint16_t, uint8_t);
void enter_console(void);

		struct consol{
			char x;
			char y;
			char string[35];
			
			}screen[15]		 = {	[0].x = 10, [0].y = 10,
									[1].x = 10, [1].y = 30,
									[2].x = 10, [2].y = 50,
									[3].x = 10, [3].y = 70,
									[4].x = 10, [4].y = 90,
									[5].x = 10, [5].y = 110,
									[6].x = 10, [6].y = 130,
									[7].x = 10, [7].y = 150,
									[8].x = 10, [8].y = 170,
									[9].x = 10, [9].y = 190,
									[10].x = 10, [9].y = 210,
									[11].x = 10, [9].y = 230
									};
		
		volatile int currentLine = 0;
		volatile int cursor_postion = 0;
		

		void refresh_dsp(void){
			
			fillScreen(ILI9341_BLACK);

			// Update TFT Display
			for(int line = 0; line < 9; line++){
				drawString(screen[line].x, screen[line].y, &screen[line].string[0], ILI9341_WHITE, ILI9341_BLACK, 2);
			}
		}

		static void scanline(int line_nr){
			
			for(int i = 0; i < 35; i++){
				
				if(screen[line_nr].string[i] == '\0'){
					screen[line_nr].string[i] = ' ';
				}
				
				screen[line_nr].string[34] = '\0';
			}
		}

		static void scroll_text(void){
			
			for(int j = 0; j < 8; j++){
				
				int i = 0;
				while(screen[j + 1].string[i] != '\0'){
				screen[j].string[i] = screen[j + 1].string[i]; i++; }
			}
			for(int j = 0; j < 35; j++)screen[8].string[j] = ' ';
		}
		
		void console_text(char * text){
			
			if(currentLine < 8){
				
				while( * text != '\0'){
					
					// Carriage Return
					if(* text == '\r'){
						cursor_postion = 0; }
				
					else if(* text == '\t'){
						cursor_postion += 4; }
					
					else if(* text == '\b'){
						cursor_postion -= 1; }
							
					// New Line
					else if(* text == '\n'){
						if(currentLine == 8){ scanline(8); scroll_text();
						}
						else{
							currentLine++;
						}
					}
					
					else{
						
						// Handle Overflow
						if(cursor_postion == 34){
							cursor_postion = 0;
							
							if(currentLine == 8){ scanline(8); scroll_text();
							}
							else{
								currentLine++;
							}
						}
						
						// Add to Screen
						screen[currentLine].string[cursor_postion++] = *text;
					}
					// Increment String Pointer
					text++;
				} scanline(currentLine);
			}
			else{
				
				while( * text != '\0'){
					
					// Carriage Return
					if(* text == '\r'){
						cursor_postion = 0; }
					
					else if(* text == '\t'){
						cursor_postion += 4; }
						
					else if(* text == '\b'){
						cursor_postion -= 1; }
					
					// New Line
					else if(* text == '\n'){
						scanline(8); scroll_text(); }
					
					else{
						
						// Handle Overflow
						if(cursor_postion == 34){
						scanline(currentLine); scroll_text(); cursor_postion = 0; }
						
						// Add to String
						screen[8].string[cursor_postion++] = *text;
					}
					// Increment string  Pointer
					text++;
				}scanline(8);
			}
			
			// Update TFT Display
			for(int line = 0; line < 9; line++){
				drawString(screen[line].x, screen[line].y, &screen[line].string[0], ILI9341_WHITE, ILI9341_BLACK, 2);
			}
		}


char ascii_prompt[100]; extern unsigned char get_scanline_code(void);

struct ipc_semaphore_object * gui = NULL; char link_char;

extern char messagePrompt[100];

void command_prompt(void);
void command_prompt(void){
	console_text(&messagePrompt[0]); 
}

char * text_prompt(uint16_t fgcolor, uint16_t bgcolor, uint8_t size){
	
	if(gui == NULL)
		gui = api_create_semaphore(1, 0);
	
	int index = 0, prompt_index = 0;
	char keypress_character;
	Bool new_command = false;
	
	for(int i =0; i < 100; i++)ascii_prompt[i] = ' ';
	
	
	if(currentLine == 0){
		drawString(0, screen[currentLine++].y, "Welcome to DARKNESS X", fgcolor, bgcolor, 2);
		drawString(0, screen[currentLine++].y, "(c) Wm. Jenkinson 2018", fgcolor, bgcolor, 2);
	}
	
	Bool back_space = false;
	
	do{
		ignore:
		
		flush_ps2();
		keypress_character = get_scanline_code();
		
		link_char = keypress_character;
		
		if(keypress_character == ENTER){
			
			
			ascii_prompt[index] = '\r';		
			if(program_active(&ascii_prompt[0]))
				link_char = 0x03;
			else
				link_char = '\r';
		}
		
		if(keypress_character == BKSP)
			link_char = '\b';
			
		api_post_semaphore(gui);
		if(new_command == false){
			prompt_index = (cursor_postion + 1) * 12; new_command = true; }
		
		if(keypress_character == ENTER)
			break;

		else if(keypress_character == BKSP) { 
	
			if(index > 0) { 
				index--; prompt_index -= 12; keypress_character = ' '; back_space = true; }
			else
				goto ignore;
		}
		
		else if(keypress_character == ';') {
			keypress_character = ':'; }
			
		
		ascii_prompt[index] = keypress_character;	
		drawChar(prompt_index, screen[currentLine].y, ascii_prompt[index], fgcolor, bgcolor, size);
		
		if(!back_space){
			prompt_index += 12; index++; }
		
		back_space = false;
	}while(true);
	
	ascii_prompt[index++] = '\r';
	ascii_prompt[index++] = '\n';
	ascii_prompt[index++] = '\0';
	
	console_text(&ascii_prompt[0]);
	return &ascii_prompt[0];
}
#endif /* TERMINAL_H_ */